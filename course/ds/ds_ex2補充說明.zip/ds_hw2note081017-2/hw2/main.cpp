#include <iostream>
#include "hw2.h"

using std::cin;
using std::cout;
using std::endl;

int main() {
	int N = 0;

	cin >> N;
	for( int i=0 ; i<N ; i++ ) {
		char x;
		/* Initial a Set and set its name (optional) */
		TSet A("A"), B("B");

		cin.ignore();
		cin >> A >> B;
		cin.get(x);

		TSet C, D; /*@\label{code_s}@*/
		C = A+B;
		D = A*B;   /*@\label{code_e}@*/

		cout << "Test Case " << (i+1) << ":" << endl;
		cout << A << endl;
		cout << B << endl;
		cout << C << endl;
		cout << D << endl;
		cout << ( A-B ) << endl;
		cout << ( B-A ) << endl;
		cout << ( A>=B ) << endl;
		cout << ( B>=A ) << endl;
		cout << A.in( x ) << endl;
		cout << B.in( x ) << endl;

		cout << endl;
	}

	return 0;
}
