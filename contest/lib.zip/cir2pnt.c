* ��~�@�I�P�ꪺ���u��{�����ײv */
/* Author: Wei-hung Yeh ������ */
#include <stdio.h>
#include <math.h>

#define INPUTFILE "cir2pnt.in"              /* ��J���ɦW*/

typedef struct POINT{
        double x,y;
}POINT;

/* center : ��ߪ��y�� (center.x,center.y)
   r      : �ꪺ�b�|
   p      : ��~�@�I���y�� (p.x,p.y)
   m1,m2  : �Ǧ^�����u�ײv
*/

#define ERROR 0                         /* �I�b�ꤺ */
#define ONLY_ONE_PERPENDICULAR_LINE 1   /* �I�b��W,���u����x�b */
#define AMONG_ONE_IS_PERPENDICULAR 2    /* ������u,�䤤�@������x�b */
#define TWO_GENERAL_LINES 3             /* ���������X�b�����u */
#define ONLY_ONE_GENERAL_LINE 4         /* �I�b��W,���u������X�b */

int point2circle_slope(POINT center, double r,POINT p, double* m1, double*
m2)
{
        double a,b,c,t;
        double D=0;
        bool OnCircle=false;

        a = p.x - center.x;
        a *= a;
        b = p.y - center.y;
        b *= b;
        c = sqrt(a + b);
        if (c < r)
                return ERROR;
        else if (c == r)
                OnCircle = true;
        b = (p.y - center.y) * (center.x - p.x);
    a = center.x - p.x;
        a *= a;
        a -= r*r;
        c = p.y - center.y;
        c *= c;
        c -= r*r;
                        
        if (a == 0 && !OnCircle){
        *m1 = (-c) / (2 * b);
                return AMONG_ONE_IS_PERPENDICULAR;
        }
        else{
                D = 4 * (b*b - a*c);
                if (D == 0){
                        if (p.y - center.y == 0)
                                return ONLY_ONE_PERPENDICULAR_LINE;
                        else{
                                *m1 = (-2*(p.y - center.y) * (center.x -
p.x)) / (2*a);
                                return ONLY_ONE_GENERAL_LINE;
                        }
                }
                else{
                D = sqrt(D);
                t = -2*(p.y - center.y) * (center.x - p.x);
                *m1 = (t + D) / (2*a);
                *m2 = (t - D) / (2*a);
                return TWO_GENERAL_LINES;
                }
        }
}

void main(void)
{
        double m1,m2;
        int count;
        POINT c,p;
        double r;
    FILE *in_file=fopen(INPUTFILE,"r");

        count = 0;
        while(fscanf(in_file,"%lf%lf%lf%lf%lf",&c.x,&c.y,&r,&p.x,&p.y) !=
EOF){
                printf("Case %d:\n",++count);
                switch (point2circle_slope(c,r,p,&m1,&m2)){
                case ERROR:
                        printf("The point is inside the circle.\n");
                        break;
                case ONLY_ONE_PERPENDICULAR_LINE:
                        printf("Just one line is x = %.6lf\n",p.x);
                        break;
                case AMONG_ONE_IS_PERPENDICULAR:
                        printf("One slope is %.6lf\n",m1);
                        printf("Another line is x = %.6lf\n",p.x);
                        break;
                case TWO_GENERAL_LINES:
                        printf("1st slope is %.6lf\n",m1);
                        printf("2nd slope is %.6lf\n",m2);
                        break;
                case ONLY_ONE_GENERAL_LINE:
                        printf("Just one slope:%.6lf\n",m1);
                        break;
                }
        }
        fclose(in_file);
}

/* test data format:
       input file name: cir2pnt.in
  Sample Input: (���.x ���.y ��b�| �I.x �I.y)
  1 1 2 3 3     ���u�@������,�@������x�b
  1 1 2 2 2     �I�b�ꤺ
  1 1 2 1 3     �I�b��W,���u�u���@��,����x�b
  1 1 2 -1 1    �I�b��W,���u�u���@��,����x�b
  1 1 2 5 5     ��������u

  Sample Output:
  Case 1:
  One slope is 0.000000
  Another line is x = 3.000000
  Case 2:
  The point is inside the circle.
  Case 3:
  Just one slope:0.000000
  Case 4:
  Just one line is x = -1.000000
  Case 5:
  1st slope is 2.215250
  2nd slope is 0.451416
*/


