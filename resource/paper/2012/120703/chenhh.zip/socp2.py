from cvxopt import matrix, solvers
c = matrix([100., 199., -5500., -6100.])

#constraint 1
G = [ matrix( [[-0.01, -0.005, 0, 0, 0], [-0.02, 0, -0.02, 0, 0], [0.5, 0, 0, 0, 0], [0.6, 0, 0, 0, 0]] ) ]
h = [ matrix( [0., 0., 0., 0., 0.] )]

#constraint 2
G += [ matrix( [[1.], [1.], [0], [0]] ) ]
h += [ matrix( [1000.] )]

#constraint 3
G += [ matrix( [[0], [0], [90.], [100.]] ) ]
h += [ matrix( [2000.] )]

#constraint 4
G += [ matrix( [[0], [0], [40.], [50.]] ) ]
h += [ matrix( [800.] )]

#constraint 5
G += [ matrix( [[100.], [199.], [700.], [800.]] ) ]
h += [ matrix( [1e5] )]

#constraint 6
G += [ matrix( [[-1.], [0], [0], [0]] ) ]
h += [ matrix( [0.] )]

#constraint 7
G += [ matrix( [[0], [-1.], [0], [0]] ) ]
h += [ matrix( [0.] )]

#constraint 8
G += [ matrix( [[0], [0 ], [-1.], [0]] ) ]
h += [ matrix( [0.] )]

#constraint 9
G += [ matrix( [[0], [0], [0], [-1.]] ) ]
h += [ matrix( [0.] )]

#sol
sol = solvers.socp(c, Gq = G, hq = h)
print "G0:",G[0]
print "h0:", h[0]
print "G1:",G[1]
print "h1:", h[1] 
print sol['x']
